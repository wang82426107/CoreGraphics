//
//  SDView.m
//  CoreGraphics01
//
//  Created by songjc on 16/9/6.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDView.h"



@implementation SDView


- (void)drawRect:(CGRect)rect {
    
    //获取上下文
    CGContextRef contextRef = UIGraphicsGetCurrentContext();

    //创建路径
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGPathMoveToPoint(path, nil, 100, 100);
    
    CGPathAddLineToPoint(path, nil, 200, 200);
    
    CGContextAddPath(contextRef, path);
    
    //设置图形上下文状态属性
    CGContextSetRGBStrokeColor(contextRef, 1.0, 0, 0, 1);//设置笔触颜色
    CGContextSetRGBFillColor(contextRef, 0, 1.0, 0, 1);//设置填充色
    CGContextSetLineWidth(contextRef, 5.0);//设置线条宽度
    CGContextSetLineCap(contextRef, kCGLineCapButt);//设置顶点样式
    CGContextSetLineJoin(contextRef, kCGLineJoinRound);//设置连接点样式
//    CGFloat lengths[2] = { 18, 9 };
//    CGContextSetLineDash(contextRef, 0, lengths, 2);//设置虚线
//    CGContextSetShadowWithColor(contextRef, CGSizeMake(2, 2), 0, [UIColor blackColor].CGColor);
    CGContextDrawPath(contextRef, kCGPathFillStroke);//最后一个参数是填充类型
    
    CGPathRelease(path);
}

@end
