//
//  ViewController.m
//  CoreGraphics01
//
//  Created by songjc on 16/9/6.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "SDView.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SDView *view = [[SDView alloc]initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:view];

}

@end
