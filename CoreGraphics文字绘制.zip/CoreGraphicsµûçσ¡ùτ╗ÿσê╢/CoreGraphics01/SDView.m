//
//  SDView.m
//  CoreGraphics01
//
//  Created by songjc on 16/9/6.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDView.h"



@implementation SDView


- (void)drawRect:(CGRect)rect {
  
//    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
//    
//    paragraphStyle.lineSpacing = 10;// 字体的行间距
//    
//    paragraphStyle.firstLineHeadIndent = 20.0f;//首行缩进
//    
//    paragraphStyle.alignment = NSTextAlignmentJustified;//（两端对齐的）文本对齐方式：（左，中，右，两端对齐，自然）
//    
//    paragraphStyle.lineBreakMode = NSLineBreakByTruncatingTail;//结尾部分的内容以……方式省略 ( "...wxyz" ,"abcd..." ,"ab...yz")
//    
//    paragraphStyle.headIndent = 20;//整体缩进(首行除外)
//    
//    paragraphStyle.tailIndent = 20;//尾部缩进
//    
//    paragraphStyle.minimumLineHeight = 10;//最低行高
//    
//    paragraphStyle.maximumLineHeight = 20;//最大行高
//    
//    paragraphStyle.paragraphSpacing = 15;//段与段之间的间距
//    
//    paragraphStyle.paragraphSpacingBefore = 22.0f;//段首行空白空间/* Distance between the bottom of the previous paragraph (or the end of its paragraphSpacing, if any) and the top of this paragraph. */
//    
//    paragraphStyle.baseWritingDirection = NSWritingDirectionLeftToRight;//从左到右的书写方向（一共➡️⬇️⬅️三种）
//    
//    paragraphStyle.lineHeightMultiple = 15;/* Natural line height is multiplied by this factor (if positive) before being constrained by minimum and maximum line height. */
//    
//    paragraphStyle.hyphenationFactor = 1;//连字属性 在iOS，唯一支持的值分别为0和1
//    
//    NSShadow *shadow = [[NSShadow alloc]init];
//    
//    shadow.shadowBlurRadius = 5;//模糊度
//    
//    shadow.shadowColor = [UIColor whiteColor];//阴影颜色
//    
//    shadow.shadowOffset = CGSizeMake(1, 5);//阴影的大小
//
    
    
    
    
    //文字居中显示在画布上
    
    NSMutableParagraphStyle* paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paragraphStyle.alignment=NSTextAlignmentCenter;//文字居中
    NSString *string  = @"逆战";
    
    [string drawInRect:CGRectMake(100, 100, 100, 100) withAttributes:@{
                                                                       NSFontAttributeName:[UIFont systemFontOfSize:17],
                                                                       NSForegroundColorAttributeName:[UIColor blackColor],
                                                                       
                                                                       NSParagraphStyleAttributeName:
                                                                           
                                                                       paragraphStyle
                                                                       
                                                                       
                                                                       }];
    
}

@end
