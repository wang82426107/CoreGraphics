//
//  SDView.m
//  CoreGraphics仿射变换
//
//  Created by songjc on 16/9/7.
//  Copyright © 2016年 Don9 联系QQ:676758285. All rights reserved.
//

#import "SDView.h"

@implementation SDView


- (void)drawRect:(CGRect)rect {
    
    //创建平移变化结构体
    CGAffineTransform translationAffineTransform = CGAffineTransformMakeTranslation(100, 0);
    
    //创建缩放变化结构体
    CGAffineTransform scaleAffineTransform = CGAffineTransformMakeScale(0.5, 1);
    
    //创建缩放变化结构体
    CGAffineTransform rotationAffineTransform = CGAffineTransformMakeRotation(0.2);
    
    //获取图形上下文
    CGContextRef context = UIGraphicsGetCurrentContext();


//    //创建路径
//    CGPathRef path = CGPathCreateWithRect(CGRectMake(100, 100, 100, 100), nil);
//    
//    //创建路径(平移)
//    CGPathRef path = CGPathCreateWithRect(CGRectMake(100, 100, 100, 100), &translationAffineTransform);
    
//    //创建路径(缩放)
//    CGPathRef path = CGPathCreateWithRect(CGRectMake(100, 100, 100, 100), &scaleAffineTransform);
//
    //创建路径(旋转)
    CGPathRef path = CGPathCreateWithRect(CGRectMake(100, 100, 100, 100), &rotationAffineTransform);

    //添加路径
    CGContextAddPath(context, path);
    
    //设置颜色
    CGContextSetRGBStrokeColor(context, 1.0, 0, 0, 1);
    
    //绘制
    CGContextDrawPath(context, kCGPathFillStroke);

    //删除路径
    CGPathRelease(path);

}

@end
